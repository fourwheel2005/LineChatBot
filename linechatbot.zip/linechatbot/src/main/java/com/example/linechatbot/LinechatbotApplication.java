package com.example.linechatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinechatbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinechatbotApplication.class, args);
	}

}
