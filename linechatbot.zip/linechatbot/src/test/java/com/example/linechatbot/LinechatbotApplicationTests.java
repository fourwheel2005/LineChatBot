package com.example.linechatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinechatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
